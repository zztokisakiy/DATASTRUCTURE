# MOSAD_HW2实验报告
## 实验目的
1. 学习使用纯代码进行UI布局
2. 学习TableView，UICollectionView，UINavigationController，UICollectionController，UITabBarController等组件的使用，以及delegate和protocol的概念。
3. 学习使用UIView动画及Core Animation动画
## 实验内容
实现一个包含若干页面和子页面的“打卡”App
## 实验情况
### TabBarController
*这部分内容位于 ``ViewController.m`` 文件中*

App的最外层是一个TabBarController, 如下图所示:

![](img/1.png)

在上图中, 下层的导航栏是TabBarController的多个TabBarItem, 对于每个TabBarItem, 可以设置对应的图片属性和文字属性(内容和颜色等). 上层的主要页面是每个TabBarItem所对应的Controller, 在每个Controller中都可以设计出各自的View来渲染不同的界面.

#### TabBarItem的文字属性

根据设计而言, 一共有三个TabBarItem, 每个Item都有各自的文字标识. 这个标识可以简单地通过``item.title``属性进行修改:
```objectiveC
disc.tabBarItem.title = @"发现";
```
其中, ``disc``是"打卡清单"所对应的controller, 这个controller将在最后加入到TabBarController中.

此外, 由于规定了选定的颜色和不选定的颜色是不一致的, 因此还需要修改相关的属性来达到此效果:
```objectiveC
[disc.tabBarItem setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor redColor]} forState:UIControlStateSelected];
```
在上面的代码中, 对``UIControlStateSelected``的状态下的文字属性设定为了红色状态.

对于"打卡"和"我的"界面用相同的方法设置, 并分别命名为"checkc"和"uic", 然后通过下列代码将三个Controller加入到TabBarController中, 并在最后将此TabBarController加入到全局Controller中:
```objectiveC
utbc.viewControllers = @[disc, checkc, uic];
[self.navigationController setViewControllers:@[utbc]];
```
最终得到的效果如下:

![](img/3.png)

![](img/4.png)

可以看到, 在选中的情况下文字呈现了红色, 而未选中的情况下文字呈现了默认的黑色.

#### TabBarItem的图片属性
在上面的展示中, 可以看到Item的图片的颜色也随着选定与不选定的状态进行改变的. 图片的颜色无法通过ObjectiveC的默认属性修改, 因此我们要为每个Item准备两张状态的图片(选定状态下为红色的图片, 非选定状态下为黑色的图片)

在TabBarItem下的图片中, 经过尝试, 大小为25像素\*25像素的图片效果比较好.

然后, 要想让XCode能够找到这些图片, 打开XCode项目的``Assets.xcassets``文件, 然后将准备好的图片拉入到XCode内部(如下图所示):

![](img/2.png)

然后, 通过下面的代码可以加载图片为UIImage:
```ObjectiveC
self.discoverImage = [UIImage imageNamed:@"search.png" inBundle:[NSBundle mainBundle] compatibleWithTraitCollection:nil];
```
``search.png``是对应的图标文件, 类似的, 通过下面的代码加载选定状态下的图片:
```ObjectiveC
self.discover_selectedImage = [UIImage imageNamed:@"search_selected.png" inBundle:[NSBundle mainBundle] compatibleWithTraitCollection:nil];
```
加载图片完成后, 将这两张图片加入到Item的image或selectedImage属性当中:
```ObjectiveC
[disc.tabBarItem setImage:[self.discoverImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
[disc.tabBarItem setSelectedImage:[self.discover_selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];    
```
通过这样设置, 就可以设定选定和非选定两个状态下的图片. 在用户看来, APP就像是通过同一个图片进行加载(而实际上我们用了两张图).

### 打卡界面
这部分内容位于``Controllers/Checkout*``中

打卡界面可以分为两个部分:
1. 搜索框(可以通过一个简单的文本框+输入事件实现)
2. 打卡内容展示(可以通过CollectionView实现)
3. 背景颜色渐变(使用一个UIView)

#### 搜索框
搜索框可以使用系统默认的UITextField实现, 但由于UITextField有很多属性需要重复设置(例如, 需要重复设置边框, 内边距, 默认填充字符等), 因此, 为了简单起见, 我首先实现了一个UITextField的子类NewTextField:
```ObjectiveC
@implementation NewTextField

static CGFloat leftMargin = 5;

- (CGRect)textRectForBounds:(CGRect)bounds {
    bounds.origin.x += leftMargin;

    return bounds;
}

- (CGRect)editingRectForBounds:(CGRect)bounds {
    bounds.origin.x += leftMargin;

    return bounds;
}
@end
```
这个子类解决了内部边界的问题(而直接使用UITextField不容易实现)

然后, 可以通过NewTextField(其实也只是一个UITextField)的其他属性的设置来完成其他内容的设置. 相关代码如下:
```ObjectiveC
self.search = [[NewTextField alloc] initWithFrame:CGRectMake(10, 100, 355, 30)];
self.search.placeholder = @"搜索：时间/地点/心得";
self.search.layer.borderColor = [UIColor systemBlueColor].CGColor;
self.search.layer.borderWidth = 1;
[self.search addTarget:self action:@selector(searchChange) forControlEvents: UIControlEventEditingChanged];
```
其中, 上面通过``UIField.addTarget``方法为搜索框添加了"当编辑时"事件, 使得用户对输入框进行修改时, 程序可以通过调用某些函数来完成打卡内容的搜索.

而在本程序中, 搜索框的搜索功能比较简单, 只是通过对时间/地点/心得三个字符串进行子串搜索而已. 相关代码为:
```ObjectiveC
- (void) searchChange {
    [self.checks removeAllObjects];
    for(NSInteger i = 0; i<self.allChecks.count; i++) {
        if([self sameAsSearch:(Check*) self.allChecks[i]]) {
            [self addToShowChecks:(Check*)self.allChecks[i]];
        }
    }
    [self reloadData];
}

- (BOOL) sameAsSearch:(Check*) check {
    // to test if check is searched by self.search
    if([self.search.text isEqualToString:@""]) {
        return YES;
    } else {
        if(
           [check.time containsString:self.search.text] ||
           [check.area containsString:self.search.text] ||
           [check.feel containsString:self.search.text]
        ) {
            return YES;
        }
    }
    return NO;
}
```
#### 打卡列表
打卡列表使用UICollectionView和UICollectionViewCell进行展示. 其中, UICollectionViewCell是UICollectionView的一部分, 或者说, UICollectionView是一个大容器, 容器内部是UICollectionViewCell, 装载着每个元素.

![](img/5.png)

如上图所示, 红色方框标注的是整个UICollectionViewCell, 而蓝色方框标注的是一个个UICollectionViewCell. 在使用的时候, 我们需要自己继承UICollectionViewCell, 并且为UICollectionView添加代理以指明数据.

下面是相关的代码:
```ObjectiveC

```

#### 渐变背景
渐变背景需要用一个UIView实现. 下面为相关代码:
```ObjectiveC
@implementation DiscoverBackgroundView


- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    CGColorSpaceRef rgb = CGColorSpaceCreateDeviceRGB();
    CGFloat colors[] =
    {
        1.0, 1.0, 1.0 ,0.2,
        0.5, 0.0, 0.5, 0.2,
        0.0, 0.0, 1.0, 0.2,
        0.0, 0.0, 0.0, 0.1,
    };
    CGGradientRef gradient = CGGradientCreateWithColorComponents(rgb, colors, NULL, 4);

    CGPoint start = CGPointMake(0, 0);
    CGPoint end = CGPointMake(self.frame.size.width, self.frame.size.height);

    CGContextRef graCtx = UIGraphicsGetCurrentContext();
    CGContextDrawLinearGradient(graCtx, gradient, start, end, 0);
    CGGradientRelease(gradient);
    gradient=nil;
    CGColorSpaceRelease(rgb);
}

@end
```

在这个UIView中,通过重写``drawRect``方法以表明如何渲染. ``colors``数组每四个元素分别代表RGB三个坐标以及不透明度.

此外, 在渲染的时候, 需要先渲染背景(不然就会导致背景覆盖了打卡列表和搜索框的情况). 还需要将打卡列表的UICollectionView的背景颜色设置为``clearColor``表示透明.

最终结果:

![](img/6.png)

### 打卡详情

从打卡列表切换到打卡详情需要增加一个自定义动画, 本程序中的自定义动画使用了系统自带的``CATransition``并在调用子Controller时加入. 动画效果为将打卡详情从手机下方滑出, 但由于使用模拟器太卡, 因此无法进行截屏. 相关代码如下:
```ObjectiveC
CATransition* transition = [CATransition animation];
transition.duration = 0.5;
transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
transition.type = kCATransitionReveal;
transition.subtype = kCATransitionFromTop;

// 添加动画
[self.navigationController.view.layer addAnimation:transition forKey:nil];
```

从打卡列表切换到打卡详情中, 可以使用系统自带的``navigationController``, 将一个打卡详情的Controller通过``pushViewController``方法直接使用.

以下是相关代码:
```ObjectiveC
- (void) gotoDetail:(Check*) check {
    DetailController* dc = [[DetailController alloc] initWithCheck:check withsu:self.su];
    
    CATransition* transition = [CATransition animation];
    transition.duration = 0.5;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionReveal;
    transition.subtype = kCATransitionFromTop;
    
    // 添加动画
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    
    [self.navigationController pushViewController:dc animated:YES];
}
```

在上面的代码中, 首先新建了一个Controller(并且在此时对打卡的内容进行传递), 然后直接调用``self``的方法.

以下是打卡详情的页面:

![](img/7.png)

上面的图片将会自动适应"打卡心得"的内容, 当打卡心得的内容较多时, 图片将会自动下降位置. 但是图片不会位于太高的位置.

### 添加打卡
一个打卡由以下几个元素组成:
1. 打卡时间
2. 打卡地点
3. 景点名称
4. 打卡心得
5. 图片

由于这次的项目比较简单, 可以忽略时间合法的校验. 将时间、地点、景点名称和打卡心得都视作``NSString``即可.

对于图片, 可以视为UIImage. 在IOS中, 可以使用ImagePickerController来获得系统相册中的图片. 这个模块可以直接返回UIImage*. 然后, 我们将这些图片保存在一个数组中, 并通过UICollectionView和UICollectionViewCell进行渲染.

对于加号, 其存放的位置为:
1. 如果图片的数量恰好为3的倍数, 那么需要额外的一行放置加号;
2. 如果图片的数量不为3的倍数, 那么在最后一行中追加一个加号.

加号是一个图片, 通过UIImage放置. 由于UIImage也是一个UIView, 因此可以为加号图片添加一个``UIGestureRecognizer``手势, 然后在此手势中定义一个方法响应``UITapGestureRecognizer``手势事件. 然后再这个事件中唤起ImagePickerController即可.

其添加打卡的大致流程为:
1. 填写时间、地点、名称和打卡心得：

![](img/8.png)

2. 点击加号, 唤起了系统的照片选择器:

![](img/9.png)

3. 选择照片后, 返回到打卡界面, 可以继续选择或提交打卡:

![](img/10.png)

4. 提交后, 将会显示提示框. 然后在用户点击确认后, 或等待一段短暂时间后, 自动切换回"打卡列表界面":

![](img/11.png)

![](img/12.png)

### "我的"界面
我的界面中实现的是登录+渐变背景功能. 在登录后需要显示一定的信息.

#### 登录+渐变背景
渐变是从中间到四周渐变.渐变的代码与"打卡列表"中的渐变思路基本相同.


实现情况展示:

![](img/13.png)

当点击"登录"的圆形框后, 将会进入到登录界面. 为了更加贴近真实, 我做了一个简单的登录框:

![](img/14.png)

在输入任意的用户名和密码后, 即可登录到"已登录"界面:

![](img/15.png)

![](img/16.png)

由于用户名和密码不是必要的, 因此其实是否登录不影响用户的使用.

通过点击已登录界面的"登出"按钮, 可以模拟用户的"退出"动作, 然后返回到登录+渐变背景的页面:

![](img/13.png)