//
//  PhotoCell.h
//  homework2
//
//  Created by caojen on 2020/10/28.
//  Copyright © 2020 caojen. All rights reserved.
//

#ifndef PhotoCell_h
#define PhotoCell_h
#import <UIKit/UIKit.h>
#import "CheckoutController.h"
@class CheckoutController;
@interface PhotoCell : UICollectionViewCell

- (void) setController:(nonnull CheckoutController*)controller;
- (void) setProperty:(nonnull UIImage*) image1 with:(nullable UIImage*)image2 with:(nullable UIImage*) image3 canClick:(NSInteger) index;

@end

#endif /* PhotoCell_h */
