//
//  CheckoutController.h
//  hw2
//
//  Created by caojen on 2020/10/27.
//  Copyright © 2020 caojen. All rights reserved.
//

#ifndef CheckoutController_h
#define CheckoutController_h
#import <UIKit/UIKit.h>
#import "LoginController.h"
#import "Check.h"
#import "DiscoverController.h"
#import "PhotoCell.h"

@class NewTextField;
@class DiscoverController;
@interface CheckoutController : UIViewController

- (CheckoutController*) initWithSuper:(UIViewController* ) su;
- (void) setDiscoverController:(DiscoverController*) dc;
- (IBAction)openPickerPickController;

@end

@interface NewTextView : UITextView

@end

#endif /* CheckoutController_h */
