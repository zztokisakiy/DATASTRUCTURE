//
//  CheckCell.h
//  homework2
//
//  Created by caojen on 2020/10/28.
//  Copyright © 2020 caojen. All rights reserved.
//

#ifndef CheckCell_h
#define CheckCell_h
#import <UIKit/UIKit.h>
#import "Check.h"
#import "DiscoverController.h"

@class DiscoverController;
@interface CheckCell : UICollectionViewCell

- (CheckCell*) initWithCheck:(NSMutableArray*) checks at:(NSInteger) index;
- (void) setDC:(DiscoverController*) dc;
- (void) setProperty:(Check*) check;

@end

#endif /* CheckCell_h */
