//
//  CheckCell.m
//  homework2
//
//  Created by caojen on 2020/10/28.
//  Copyright © 2020 caojen. All rights reserved.
//

#import "CheckCell.h"

@interface CheckCell ()

@property(strong, nonatomic) UILabel* card;
@property(strong, nonatomic) Check* check;
@property(strong, nonatomic) DiscoverController* dc;

@end

@implementation CheckCell

- (CheckCell*) initWithCheck:(NSMutableArray*) checks at:(NSInteger) index {
    self = [self init];
    self.check = checks[index];
    return self;
}

- (void) setDC:(DiscoverController*) dc {
    self.dc = dc;
}

- (void) setProperty:(Check*) check {
    self.check = check;
    
    self.card = [[UILabel alloc] initWithFrame:CGRectMake(0, 10, 355, 75)];
    self.card.layer.borderColor = [UIColor blackColor].CGColor;
    self.card.layer.borderWidth = 1;
    self.card.layer.cornerRadius = 15;
    
    [self.card setNumberOfLines:3];
    self.card.text = [[[[[@"  打卡时间：" stringByAppendingString:check.time] stringByAppendingString:@"\n  打卡地点："] stringByAppendingString:check.area]stringByAppendingString:@"\n  旅游心得："]stringByAppendingString:[check.feel substringToIndex:(20 > check.feel.length ? check.feel.length : 20)]];
    
    UIGestureRecognizer* addPicture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(getCheckDetail)];
    [self.card addGestureRecognizer:addPicture];
    self.card.userInteractionEnabled = true;
    
    [self addSubview:self.card];
}

- (void) getCheckDetail {
    [self.dc gotoDetail:self.check];
}

@end
