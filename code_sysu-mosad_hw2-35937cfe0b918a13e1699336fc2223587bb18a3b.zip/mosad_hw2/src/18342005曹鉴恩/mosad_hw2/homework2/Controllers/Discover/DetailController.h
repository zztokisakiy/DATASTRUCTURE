//
//  DetailController.h
//  homework2
//
//  Created by caojen on 2020/10/28.
//  Copyright © 2020 caojen. All rights reserved.
//

#ifndef DetailController_h
#define DetailController_h

#import <UIKit/UIKit.h>
#import "Check.h"
#import "PhotoCell.h"

@interface DetailController : UIViewController

- (DetailController*) initWithCheck:(Check*) check withsu:(UIViewController*) su;

@end

#endif /* DetailController_h */
