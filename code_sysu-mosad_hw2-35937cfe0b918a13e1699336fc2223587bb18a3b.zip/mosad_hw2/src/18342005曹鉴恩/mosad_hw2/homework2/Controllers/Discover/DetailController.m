//
//  DetailController.m
//  homework2
//
//  Created by caojen on 2020/10/28.
//  Copyright © 2020 caojen. All rights reserved.
//

#import "DetailController.h"

@interface DetailController () <UICollectionViewDataSource, UICollectionViewDelegate>

@property(strong, nonatomic) Check* check;
@property(strong, nonatomic) UIViewController* su;
@property(strong, nonatomic) UILabel* timeLabel;
@property(strong, nonatomic) UILabel* areaLabel;
@property(strong, nonatomic) UILabel* placeLabel;
@property(strong, nonatomic) UILabel* feelLabel;
@property(strong, nonatomic) UICollectionView* photos;
@property(strong, nonatomic) NSMutableArray* photodata;

@end

@implementation DetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self loadDetail];
}

- (DetailController*) initWithCheck:(Check*) check withsu:(UIViewController*) su {
    self = [self init];
    self.check = check;
    self.photodata = check.photos;
    self.su = su;
    return self;
}

- (void) loadDetail {
    [self setTitle:@"查看打卡"];
    
    self.timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 100, 300, 30)];
    self.timeLabel.text = self.check.time;
    self.timeLabel.font = [UIFont systemFontOfSize:15];
    [self.view addSubview:self.timeLabel];
    
    self.areaLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 140, 300, 30)];
    self.areaLabel.text = self.check.area;
    self.areaLabel.font = [UIFont systemFontOfSize:15];
    [self.view addSubview:self.areaLabel];
    
    self.placeLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 180, 300, 30)];
    self.placeLabel.text = self.check.place;
    self.placeLabel.font = [UIFont systemFontOfSize:15];
    [self.view addSubview:self.placeLabel];
    
    self.feelLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 220, 330, 330)];
//    self.feelLabel.layer.borderColor = [UIColor systemBlueColor].CGColor;
//    self.feelLabel.layer.borderWidth = 1;
    [self.feelLabel setNumberOfLines:0];
    [self.feelLabel setLineBreakMode:NSLineBreakByWordWrapping];
    self.feelLabel.text = self.check.feel;
    [self.feelLabel sizeToFit];
    self.feelLabel.font = [UIFont systemFontOfSize:15];
    [self.view addSubview:self.feelLabel];
    
    UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc] init];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    layout.itemSize = CGSizeMake(345, 100);
    NSInteger y = self.feelLabel.frame.size.height + self.feelLabel.frame.origin.y + 20;
    y = y < 450 ? 450 : y;
    self.photos = [[UICollectionView alloc] initWithFrame:CGRectMake(20, y, 345, 235) collectionViewLayout:layout];
    self.photos.alpha = 1;
//    self.photos.layer.borderWidth = 1;
//    self.photos.layer.borderColor = [UIColor systemBlueColor].CGColor;
    self.photos.backgroundColor = [UIColor whiteColor];
    [self.photos setDataSource:self];
    [self.photos setDelegate:self];
    [self.photos registerClass:[PhotoCell class] forCellWithReuseIdentifier:@"detail"];
    
    [self.view addSubview:self.photos];
}

- (UICollectionViewCell *)collectionView:(nonnull UICollectionView *)collectionView cellForItemAtIndexPath:(nonnull NSIndexPath *)indexPath {
    NSInteger row = indexPath.row;
    
    PhotoCell* cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"detail" forIndexPath:indexPath];
    NSInteger count = self.photodata.count;
    NSInteger from = row * 3;
    
    UIImage* image1 = nil;
    UIImage* image2 = nil;
    UIImage* image3 = nil;
    
    if(count <= from) {

    } else {
        image1 = self.photodata[from];
    }
    
    from ++;
    
    if(count <= from) {

    } else {
        image2 = self.photodata[from];
    }
    
    from ++;
    
    if(count <= from) {

    } else {
        image3 = self.photodata[from];
    }

    [cell setProperty:image1 with:image2 with:image3 canClick:0];
    
    return cell;
}

- (NSInteger)collectionView:(nonnull UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    NSInteger line;
    
    if(self.photodata.count == 0) {
        line = 1;
    } else {
        if(self.photodata.count % 3 == 0) {
            line = (self.photodata.count) / 3 + 1;
        } else {
            line = self.photodata.count / 3 + 1;
        }
    }
    
    return line;
}

@end
