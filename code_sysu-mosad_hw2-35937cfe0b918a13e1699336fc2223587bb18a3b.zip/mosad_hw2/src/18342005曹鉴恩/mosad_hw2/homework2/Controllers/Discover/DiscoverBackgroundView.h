//
//  DiscoverBackgroundView.h
//  homework2
//
//  Created by caojen on 2020/11/9.
//  Copyright © 2020 caojen. All rights reserved.
//

#ifndef DiscoverBackgroundView_h
#define DiscoverBackgroundView_h
#import "UIKit/UIKit.h"

@interface DiscoverBackgroundView : UIView

@end

#endif /* DiscoverBackgroundView_h */
