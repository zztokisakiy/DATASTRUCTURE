//
//  DiscoverBackgroundView.m
//  homework2
//
//  Created by caojen on 2020/11/9.
//  Copyright © 2020 caojen. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DiscoverBackgroundView.h"

@implementation DiscoverBackgroundView


- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    CGColorSpaceRef rgb = CGColorSpaceCreateDeviceRGB();
    CGFloat colors[] =
    {
        1.0, 1.0, 1.0 ,0.2,
        0.5, 0.0, 0.5, 0.2,
        0.0, 0.0, 1.0, 0.2,
        0.0, 0.0, 0.0, 0.1,
    };
    CGGradientRef gradient = CGGradientCreateWithColorComponents(rgb, colors, NULL, 4);

    CGPoint start = CGPointMake(0, 0);
    CGPoint end = CGPointMake(self.frame.size.width, self.frame.size.height);

    CGContextRef graCtx = UIGraphicsGetCurrentContext();
    CGContextDrawLinearGradient(graCtx, gradient, start, end, 0);
    CGGradientRelease(gradient);
    gradient=nil;
    CGColorSpaceRelease(rgb);
}

@end
