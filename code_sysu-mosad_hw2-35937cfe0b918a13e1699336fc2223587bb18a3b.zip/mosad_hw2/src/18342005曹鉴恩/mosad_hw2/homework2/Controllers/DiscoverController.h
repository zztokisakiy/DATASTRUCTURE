//
//  DiscoverController.h
//  hw2
//
//  Created by caojen on 2020/10/27.
//  Copyright © 2020 caojen. All rights reserved.
//

#ifndef DiscoverController_h
#define DiscoverController_h

#import <UIKit/UIKit.h>
#import "Check.h"
#import "LoginController.h"
#import "CheckCell.h"
#import "DetailController.h"
#import "DiscoverBackgroundView.h"

@interface DiscoverController : UIViewController<UICollectionViewDataSource, UICollectionViewDelegate>

- (DiscoverController*) initWithSuper:(UIViewController* ) su;
- (void) addCheck: (Check*) check;
- (void) gotoDetail:(Check*) check;

@end

#endif /* DiscoverController_h */
