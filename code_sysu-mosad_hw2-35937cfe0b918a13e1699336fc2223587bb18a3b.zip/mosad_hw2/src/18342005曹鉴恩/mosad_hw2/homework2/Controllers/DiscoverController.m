//
//  DiscoverController.m
//  hw2
//
//  Created by caojen on 2020/10/27.
//  Copyright © 2020 caojen. All rights reserved.
//

#import "DiscoverController.h"

@interface DiscoverController ()<UICollectionViewDataSource, UICollectionViewDelegate>
@property(strong, nonatomic) UIViewController* su;
@property(strong, nonatomic) NSMutableArray* checks;    // store showing checks
@property(strong, nonatomic) NSMutableArray* allChecks; // store all checks
@property(strong, nonatomic) DiscoverBackgroundView* bgView; // background view
@property(nonatomic) NSInteger showNumber;

@property(strong, nonatomic) NewTextField* search;
@property(strong, nonatomic) UICollectionView* collections;
@end

@implementation DiscoverController

- (void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.bgView = [[DiscoverBackgroundView alloc] initWithFrame:CGRectMake(0, 0, 450, 800)];
    [self.view addSubview:self.bgView];
    
    self.checks = [[NSMutableArray alloc] init];
    self.allChecks = [[NSMutableArray alloc] init];
    self.showNumber = 3;
    
    self.search = [[NewTextField alloc] initWithFrame:CGRectMake(10, 100, 355, 30)];
    self.search.placeholder = @"搜索：时间/地点/心得";
    self.search.layer.borderColor = [UIColor systemBlueColor].CGColor;
    self.search.layer.borderWidth = 1;
    [self.search addTarget:self action:@selector(searchChange) forControlEvents: UIControlEventEditingChanged];
    [self.view addSubview:self.search];
}

- (void) searchChange {
    [self.checks removeAllObjects];
    for(NSInteger i = 0; i<self.allChecks.count; i++) {
        if([self sameAsSearch:(Check*) self.allChecks[i]]) {
            [self addToShowChecks:(Check*)self.allChecks[i]];
        }
    }
    [self reloadData];
}

- (DiscoverController*) initWithSuper:(UIViewController* ) su {
    self = [self init];
    self.su = su;
    return self;
}

- (void) reloadData {
    [self.collections removeFromSuperview];
    UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc] init];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    layout.itemSize = CGSizeMake(355, 75);
    self.collections = [[UICollectionView alloc] initWithFrame:CGRectMake(10, 145, 355, 570) collectionViewLayout:layout];
    [self.collections registerClass:[CheckCell class] forCellWithReuseIdentifier:@"discover"];
    [self.collections setDelegate:self];
    [self.collections setDataSource:self];
//    self.collections.layer.borderWidth = 1;
//    self.collections.layer.borderColor = [UIColor systemBlueColor].CGColor;
    self.collections.backgroundColor = [UIColor clearColor];
    UIGestureRecognizer* touch = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(editEnding)];
    [self.collections addGestureRecognizer:touch];
    self.collections.userInteractionEnabled = true;
    [self.view addSubview:self.collections];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.su setTitle:@"打卡记录"];
    
    [self reloadData];
}

- (void)viewWillDisappear:(BOOL)animated {
    [self.view endEditing:YES];
    [self.tabBarController.tabBarItem setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor redColor]} forState:UIControlStateSelected];
}

- (void) editEnding {
    [self.view endEditing:YES];
}

- (void) addCheck: (Check*) check {
    [self.allChecks insertObject:check atIndex:0];
    if([self sameAsSearch:check]) {
        [self addToShowChecks:check];
    }
//    [self.collections reloadData];
}

- ( UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    CheckCell* cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"discover" forIndexPath:indexPath];
    [cell setDC:self];
    [cell setProperty:self.checks[indexPath.row]];
    return cell;
}

- (NSInteger)collectionView:(nonnull UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.checks.count;
}

- (void) gotoDetail:(Check*) check {
    DetailController* dc = [[DetailController alloc] initWithCheck:check withsu:self.su];
    
    CATransition* transition = [CATransition animation];
    transition.duration = 0.5;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionReveal;
    transition.subtype = kCATransitionFromTop;
    
    // 添加动画
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    
    [self.navigationController pushViewController:dc animated:YES];
}

- (void) addToShowChecks:(Check*) check {
    // if has in, ignore
    // else insert into position base on time
    for(NSInteger i = 0; i<self.checks.count; i++) {
        if(self.checks[i] == check) {
            return;
        }
    }
    
    for(NSInteger i = 0;i<self.checks.count;i++) {
        if(((Check*)self.checks[i]).time <= check.time) {
            [self.checks insertObject:check atIndex:i];
            return;
        }
    }
    
    [self.checks addObject:check];
}

- (BOOL) sameAsSearch:(Check*) check {
    // to test if check is searched by self.search
    if([self.search.text isEqualToString:@""]) {
        return YES;
    } else {
        if(
           [check.time containsString:self.search.text] ||
           [check.area containsString:self.search.text] ||
           [check.feel containsString:self.search.text]
        ) {
            return YES;
        }
    }
    return NO;
}

@end
