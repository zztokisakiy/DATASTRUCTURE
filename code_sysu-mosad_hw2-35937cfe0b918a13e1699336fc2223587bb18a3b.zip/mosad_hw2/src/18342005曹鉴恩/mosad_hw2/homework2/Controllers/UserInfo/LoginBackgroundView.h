//
//  LoginBackgroundView.h
//  homework2
//
//  Created by caojen on 2020/11/9.
//  Copyright © 2020 caojen. All rights reserved.
//

#ifndef LoginBackgroundView_h
#define LoginBackgroundView_h

#import "UIKit/UIKit.h"

@interface LoginBackgroundView : UIView

@end

#endif /* LoginBackgroundView_h */
