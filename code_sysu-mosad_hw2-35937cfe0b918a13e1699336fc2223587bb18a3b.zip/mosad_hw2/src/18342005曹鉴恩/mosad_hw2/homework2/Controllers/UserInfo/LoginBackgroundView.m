//
//  LoginBackgroundView.m
//  homework2
//
//  Created by caojen on 2020/11/9.
//  Copyright © 2020 caojen. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LoginBackgroundView.h"

@implementation LoginBackgroundView


- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    CGColorSpaceRef rgb = CGColorSpaceCreateDeviceRGB();
    CGFloat colors[] =
    {
        1.0, 1.0, 1.0 ,0.2,
        0.5, 0.0, 0.5, 0.2,
        0.0, 0.0, 1.0, 0.2,
        0.0, 0.0, 0.0, 0.1,
    };
    CGGradientRef gradient = CGGradientCreateWithColorComponents(rgb, colors, NULL, 2);

    CGPoint start = CGPointMake(self.frame.size.width/2, self.frame.size.height/2);
    CGPoint end = CGPointMake(self.frame.size.width/2, self.frame.size.height/2);
    CGFloat startRadius = 0.0f;
    CGFloat endRadius = 400;
    CGContextRef graCtx = UIGraphicsGetCurrentContext();
    CGContextDrawRadialGradient(graCtx, gradient, start, startRadius, end, endRadius, 0);
    CGGradientRelease(gradient);
    gradient=NULL;
    CGColorSpaceRelease(rgb);
}

@end
