//
//  LoginController.h
//  homework2
//
//  Created by caojen on 2020/10/27.
//  Copyright © 2020 caojen. All rights reserved.
//

#ifndef LoginController_h
#define LoginController_h
#import <UIKit/UIKit.h>
#import "UserInfoController.h"

@class UserInfoController;
@interface LoginController : UIViewController

    - (LoginController*) initWithSuper:(UserInfoController*) su ;

@end

@interface NewTextField : UITextField

@end

#endif /* LoginController_h */
