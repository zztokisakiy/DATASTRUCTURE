//
//  UserInfoController.h
//  hw2
//
//  Created by caojen on 2020/10/27.
//  Copyright © 2020 caojen. All rights reserved.
//

#ifndef UserInfoController_h
#define UserInfoController_h
#import <UIKit/UIKit.h>
#import "LoginController.h"
#import "UserInfo.h"
#import "LoginBackgroundView.h"

@interface UserInfoController : UIViewController

- (void)login:(UserInfo*) user;
- (UserInfoController*) initWithSuper:(UIViewController* ) su ;
- (void)exitLogin;

@end

#endif /* UserInfoController_h */
