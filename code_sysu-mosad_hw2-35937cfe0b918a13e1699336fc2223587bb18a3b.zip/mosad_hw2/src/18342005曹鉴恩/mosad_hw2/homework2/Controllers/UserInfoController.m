//
//  UserInfoController.m
//  hw2
//
//  Created by caojen on 2020/10/27.
//  Copyright © 2020 caojen. All rights reserved.
//

#import "UserInfoController.h"

@interface UserInfoController ()
@property(strong, nonatomic) UIViewController* su;
@property(strong, nonatomic) UserInfo* user;

@property(strong, nonatomic) UIView* circleView;
@property(strong, nonatomic) UILabel* ul;
@property(strong, nonatomic) LoginBackgroundView* bgView;

@property(strong, nonatomic) UIImageView* uiView;
@property(strong, nonatomic) UILabel* uitf;
@property(strong, nonatomic) UILabel* about;
@property(strong, nonatomic) UILabel* aboutdetail;
@property(strong, nonatomic) UIButton *but;


@end

@implementation UserInfoController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.user = nil;
}

- (UserInfoController*) initWithSuper:(UIViewController* ) su {
    self = [self init];
    self.su = su;
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.tabBarController.tabBarItem setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor redColor]} forState:UIControlStateSelected];
    
    [self.su setTitle:@"我的"];
    if(self.user == nil) {
        if(self.bgView == nil) {
            self.bgView = [[LoginBackgroundView alloc] initWithFrame:CGRectMake(0, 0, 450, 800)];
            [self.view addSubview:self.bgView];
        }
        
        if(self.uiView != nil) {
            [self.uiView removeFromSuperview]; self.uiView = nil;
            [self.uitf removeFromSuperview]; self.uitf = nil;
            [self.about removeFromSuperview]; self.about = nil;
            [self.aboutdetail removeFromSuperview]; self.aboutdetail = nil;
            [self.but removeFromSuperview]; self.but = nil;
        }
        if(self.circleView == nil) {
            self.circleView = [[UIView alloc] initWithFrame:CGRectMake(0,0,200,200)];
            self.circleView.center = self.view.center;
            self.circleView.alpha = 0.5;
            self.circleView.layer.cornerRadius = 100;
            self.circleView.backgroundColor = [UIColor clearColor];
            self.circleView.layer.borderColor = [UIColor blueColor].CGColor;
            self.circleView.layer.borderWidth = 3;
            
            UIGestureRecognizer* clickLogin = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(gologin)];
            [self.circleView addGestureRecognizer:clickLogin];
            
            [self.view addSubview:self.circleView];
            
            self.ul = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 58, 58)];
            self.ul.center = self.view.center;
            self.ul.text = @"登录";
            self.ul.font = [UIFont systemFontOfSize:28];
            [self.view addSubview:self.ul];
        }
    } else {
        if(self.circleView != nil) {
            [self.circleView removeFromSuperview]; self.circleView = nil;
            [self.ul removeFromSuperview]; self.ul = nil;
            [self.bgView removeFromSuperview]; self.bgView = nil;
        }
        
        if(self.uiView == nil) {
            NSString* image = @"a.jpeg";
            UIImage* uiImage = [UIImage imageNamed:image inBundle:[NSBundle mainBundle] compatibleWithTraitCollection:nil];
            self.uiView = [[UIImageView alloc] initWithImage:uiImage];
            self.uiView.frame = CGRectMake(self.view.center.x / 2 + 10, 90, 160, 160);
            self.uiView.layer.cornerRadius = 80;
            self.uiView.layer.masksToBounds = YES;
            [self.view addSubview:self.uiView];
            
            NSString* username = [self user].name;
            self.uitf = [[UILabel alloc] initWithFrame:CGRectMake(65, 250, 245, 80)];
            self.uitf.layer.borderColor = [UIColor systemBlueColor].CGColor;
            self.uitf.layer.borderWidth = 1;
            
            [self.uitf setNumberOfLines:3];
            self.uitf.text = [[@" 用户名：" stringByAppendingString:username] stringByAppendingString:@"\n 邮箱：test@mail2.sysu.edu.cn\n 电话：13012345678"];
            [self.view addSubview:self.uitf];
            
            self.about = [[UILabel alloc] initWithFrame:CGRectMake(40, 375, 100, 30)];
            self.about.text = @"关于：";
            [self.view addSubview:self.about];
            
            self.aboutdetail = [[UILabel alloc] initWithFrame:CGRectMake(65, 410, 245, 170)];
            self.aboutdetail.layer.borderColor = [UIColor systemBlueColor].CGColor;
            self.aboutdetail.layer.borderWidth = 1;
            [self.aboutdetail setNumberOfLines:9];
            self.aboutdetail.text = @" 版本: v0.1.1\n\n 隐私和Cookie: X084FPLY2\n\n 清除缓存\n\n 同步";
            [self.view addSubview:self.aboutdetail];
            
            self.but= [UIButton buttonWithType:UIButtonTypeRoundedRect];
            [self.but addTarget:self action:@selector(logout) forControlEvents:UIControlEventTouchUpInside];
            [self.but setFrame:CGRectMake(180, 590, 215, 40)];
            [self.but setTitle:@"登出" forState:UIControlStateNormal];
            [self.but setExclusiveTouch:YES];

            [self.view addSubview:self.but];
        }
        
    }
}

- (void)gologin {
    LoginController* lc = [[LoginController alloc] initWithSuper:self];
    [self.navigationController pushViewController:lc animated:NO];
}

- (void)login:(UserInfo*) user {
    self.user = user;
}

- (void)exitLogin {
    [self.navigationController popViewControllerAnimated:YES];
    [self viewWillAppear:YES];
}

- (void)logout {
    self.user = nil;
    [self viewWillAppear:YES];
}
@end
