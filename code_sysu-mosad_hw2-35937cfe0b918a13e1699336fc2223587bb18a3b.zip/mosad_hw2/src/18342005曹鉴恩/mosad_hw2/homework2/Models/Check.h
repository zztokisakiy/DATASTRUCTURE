//
//  Check.h
//  homework2
//
//  Created by caojen on 2020/10/28.
//  Copyright © 2020 caojen. All rights reserved.
//

#ifndef Check_h
#define Check_h
#import <Foundation/Foundation.h>

@interface Check : NSObject
@property(strong, nonatomic) NSString* time;
@property(strong, nonatomic) NSString* area;
@property(strong, nonatomic) NSString* place;
@property(strong, nonatomic) NSString* feel;
@property(strong, nonatomic) NSMutableArray* photos;

+ (Check*) init:(NSString*) time at:(NSString*) area where:(NSString*) place with:(NSString*) feel photos:(NSMutableArray*) photos;
@end

#endif /* Check_h */
