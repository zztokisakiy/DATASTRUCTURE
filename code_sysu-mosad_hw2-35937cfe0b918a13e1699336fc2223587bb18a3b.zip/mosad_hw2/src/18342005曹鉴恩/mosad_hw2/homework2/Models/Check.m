//
//  Check.m
//  homework2
//
//  Created by caojen on 2020/10/28.
//  Copyright © 2020 caojen. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Check.h"

@implementation Check

+ (Check*) init:(NSString*) time at:(NSString*) area where:(NSString*) place with:(NSString*) feel photos:(NSMutableArray*) photos {
    Check* res = [Check alloc];
    res.time = time;
    res.area = area;
    res.place = place;
    res.feel = feel;
    res.photos = photos;
    
    return res;
}

@end
