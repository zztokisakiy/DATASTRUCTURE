//
//  UserInfo.h
//  homework2
//
//  Created by caojen on 2020/10/27.
//  Copyright © 2020 caojen. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface UserInfo : NSObject

@property(strong, nonatomic) NSString* name;
@property(strong, nonatomic) NSString* password;

+ (UserInfo*) construct:(NSString*)name with:(NSString*) password;

@end
