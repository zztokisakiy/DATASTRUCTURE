//
//  UserInfo.m
//  homework2
//
//  Created by caojen on 2020/10/27.
//  Copyright © 2020 caojen. All rights reserved.
//

#import "UserInfo.h"

@implementation UserInfo

+ (UserInfo*) construct:(NSString*)name with:(NSString*) password {
    UserInfo* userinfo = [UserInfo alloc];
    userinfo.name = name;
    userinfo.password = password;
    return userinfo;
}

@end
