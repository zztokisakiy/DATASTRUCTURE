//
//  ViewController.m
//  hw2
//
//  Created by caojen on 2020/10/27.
//  Copyright © 2020 caojen. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property(strong, nonatomic) UIImage* discoverImage;
@property(strong, nonatomic) UIImage* checkoutImage;
@property(strong, nonatomic) UIImage* userinfoImage;

@property(strong, nonatomic) UIImage* discover_selectedImage;
@property(strong, nonatomic) UIImage* checkout_selectedImage;
@property(strong, nonatomic) UIImage* userinfo_selectedImage;
@end

@implementation ViewController

- (void) viewDidLoad {
    [super viewDidLoad];
    [self showTabBar];
}

-(void) showTabBar {
    self.discoverImage = [UIImage imageNamed:@"search.png" inBundle:[NSBundle mainBundle] compatibleWithTraitCollection:nil];
    self.checkoutImage = [UIImage imageNamed:@"location.png" inBundle:[NSBundle mainBundle] compatibleWithTraitCollection:nil];
    self.userinfoImage = [UIImage imageNamed:@"profile.png" inBundle:[NSBundle mainBundle] compatibleWithTraitCollection:nil];
    
    self.discover_selectedImage = [UIImage imageNamed:@"search_selected.png" inBundle:[NSBundle mainBundle] compatibleWithTraitCollection:nil];
    self.checkout_selectedImage = [UIImage imageNamed:@"location_selected.png" inBundle:[NSBundle mainBundle] compatibleWithTraitCollection:nil];
    self.userinfo_selectedImage = [UIImage imageNamed:@"profile_selected.png" inBundle:[NSBundle mainBundle] compatibleWithTraitCollection:nil];
    
    UITabBarController* utbc = [[UITabBarController alloc] init];
    
    DiscoverController* disc = [[DiscoverController alloc] initWithSuper: self];
    disc.tabBarItem.title = @"发现";
    [disc.tabBarItem setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor redColor]} forState:UIControlStateSelected];
    disc.tabBarItem.image = self.discoverImage;
    [disc.tabBarItem setImage:[self.discoverImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [disc.tabBarItem setSelectedImage:[self.discover_selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    
    CheckoutController* checkc = [[CheckoutController alloc] initWithSuper: self];
    checkc.tabBarItem.title = @"打卡";
    [checkc.tabBarItem setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor redColor]} forState:UIControlStateSelected];
    checkc.tabBarItem.image = self.checkoutImage;
    [checkc.tabBarItem setImage:[self.checkoutImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [checkc.tabBarItem setSelectedImage:[self.checkout_selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    
    [checkc setDiscoverController:disc];
    UserInfoController* uic = [[UserInfoController alloc] initWithSuper: self];
    uic.tabBarItem.title = @"我的";
    [uic.tabBarItem setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor redColor]} forState:UIControlStateSelected];
    uic.tabBarItem.image = self.userinfoImage;
    [uic.tabBarItem setImage:[self.userinfoImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [uic.tabBarItem setSelectedImage:[self.userinfo_selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    
    utbc.viewControllers = @[disc, checkc, uic];

    [self.navigationController setViewControllers:@[utbc]];
}

@end
